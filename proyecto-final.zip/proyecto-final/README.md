## Arrancar proyecto
- La manera en la cual se arranca el proyecto es 
* instalando sus dependencias con npm i 
* Corriendo el programa con: npm start