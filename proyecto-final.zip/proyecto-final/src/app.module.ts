import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { config } from 'dotenv';
import { ProductModule } from './core/produccion/product/product.module';
import { WorkOrderModule } from './core/produccion/work-order/work-order.module';
import Product from './core/produccion/product/product.entity';
import ScrapReason from './core/produccion/scrap-reason/ScrapReason.entity';
import { ScrapReasonModule } from './core/produccion/scrap-reason/scrap-reason.module';
import { LocationModule } from './core/produccion/location/location.module';
import { ProductInventoryModule } from './core/produccion/product-inventory/product-inventory.module';
import { ProductVendorModule } from './core/compras/product-vendor/product-vendor.module';
import { PurchaseOrderDetailModule } from './core/compras/purchase-order-detail/purchase-order-detail.module';
import WorkOrder from './core/produccion/work-order/work-order.entity';
import Location from './core/produccion/location/location.entity';
import ProductInventory from './core/produccion/product-inventory/product-inventory.entity';
import ProductVendor from './core/compras/product-vendor/product-vendor.entity';
import PurchaseOrderDetail from './core/compras/purchase-order-detail/purchase-order-detail.entity';
config();
console.log(process.env);
@Module({
  imports: [
    TypeOrmModule.forRoot({
      name: 'production',
      type: 'mssql',
      host: process.env.HOST_ONE, // localhost o aws.......
      port: 1433,
      username: process.env.USER_ONE,
      password: process.env.PASSWORD_ONE,
      database: 'Produccion',
      entities: [
        Product,
        ScrapReason,
        WorkOrder,
        Location,
        ProductInventory,
        ScrapReason,
      ],
      options: { encrypt: false },
    }),
    TypeOrmModule.forRoot({
      name: 'compras',
      type: 'mssql',
      host: process.env.HOST_TWO, // localhost o aws.......
      port: 1433,
      username: process.env.USER_TWO,
      password: process.env.PASSWORD_TWO,
      database: 'Compras',
      entities: [ProductVendor, PurchaseOrderDetail],
      options: { encrypt: false },
    }),

    ScrapReasonModule,
    ProductModule,
    WorkOrderModule,
    LocationModule,
    ProductInventoryModule,
    ProductVendorModule,
    PurchaseOrderDetailModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
