import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ProductService } from 'src/core/produccion/product/product.service';
import { Repository } from 'typeorm';
import PurchaseOrderDetail from './purchase-order-detail.entity';

@Injectable()
export class PurchaseOrderDetailService {
  constructor(
    @InjectRepository(PurchaseOrderDetail, 'compras')
    private repository: Repository<PurchaseOrderDetail>,
    private productService: ProductService,
  ) {}

  // --7.- Listar las compras de productos que se esperen lleguen antes del 24 de febrero del 2014;
  async productsBeforeChristmas() {
    const product = await this.productService.getProducts();
    const ids = product.map(({ ProductID }) => ProductID);
    if (!product) throw new Error('El producto no existe');
    return await this.repository
      .createQueryBuilder('ProductVendor')
      .where('ProductVendor.DueDate < :date', {
        date: '2014-02-24',
      })
      .andWhere('ProductVendor.ProductID IN (:...ids)', {
        ids,
      })
      .getRawMany(); // userId is not a foreign key since its cross-database request
  }
}
