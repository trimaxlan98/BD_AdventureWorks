import { Controller, Get } from '@nestjs/common';

import { PurchaseOrderDetailService } from './purchase-order-detail.service';

@Controller('purchase-order-detail')
export class PurchaseOrderDetailController {
  constructor(private service: PurchaseOrderDetailService) {}
  @Get('/christmas')
  async getProducts() {
    return await this.service.productsBeforeChristmas();
  }
}
