import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProductModule } from 'src/core/produccion/product/product.module';
import { PurchaseOrderDetailController } from './purchase-order-detail.controller';
import PurchaseOrderDetail from './purchase-order-detail.entity';
import { PurchaseOrderDetailService } from './purchase-order-detail.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([PurchaseOrderDetail], 'compras'),
    ProductModule,
  ],
  controllers: [PurchaseOrderDetailController],
  providers: [PurchaseOrderDetailService],
})
export class PurchaseOrderDetailModule {}
