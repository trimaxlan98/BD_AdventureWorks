import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';

@Entity({
  database: 'Compras',
  schema: 'Purchasing',
  name: 'PurchaseOrderDetail',
})
export default class PurchaseOrderDetail {
  @PrimaryGeneratedColumn('increment')
  PurchaseOrderID: number;

  @Column()
  DueDate: Date;

  @Column()
  OrderQty: number;

  @Column()
  ProductID: number;

  @Column()
  UnitPrice: number;

  @Column()
  LineTotal: number;

  @Column()
  ReceivedQty: number;

  @Column()
  RejectedQty: number;

  @Column()
  StockedQty: number;

  @Column()
  ModifiedDate: Date;

  @ManyToOne(
    () => PurchaseOrderDetail,
    (purchaseOrderDetail) => purchaseOrderDetail.p1,
  )
  @JoinColumn({ name: 'PurchaseOrderDetailID' })
  p1: PurchaseOrderDetail;

  @OneToMany(
    () => PurchaseOrderDetail,
    (purchaseOrderDetail) => purchaseOrderDetail.p2,
  )
  p2: PurchaseOrderDetail;
}
