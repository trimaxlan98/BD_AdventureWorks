import { Controller, Get, Param } from '@nestjs/common';
import { ProductVendorService } from './product-vendor.service';

@Controller('product-vendor')
export class ProductVendorController {
  constructor(private productVendorService: ProductVendorService) {}
  @Get('days/:days')
  async get(@Param('days') days: number) {
    return await this.productVendorService.productsByDays(days);
  }

  @Get('dolars/:dolars')
  async moreThan(@Param('dolars') dolars: number) {
    return await this.productVendorService.moreThan(dolars);
  }
}
