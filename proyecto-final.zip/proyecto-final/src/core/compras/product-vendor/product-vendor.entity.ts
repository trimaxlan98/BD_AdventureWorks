import { Column, Entity, PrimaryColumn } from 'typeorm';

@Entity({ database: 'Compras', schema: 'Purchasing', name: 'ProductVendor' })
export default class ProductVendor {
  @PrimaryColumn()
  ProductID: number;

  @Column()
  BusinessEntityID: number;

  @Column()
  AverageLeadTime: number;

  @Column()
  StandardPrice: number;

  @Column()
  LastReceiptCost: number;

  @Column()
  MinOrderQty: number;

  @Column()
  MaxOrderQty: number;

  @Column()
  OnOrderQty: number;

  @Column()
  UnitMeasureCode: number;

  @Column()
  ModifiedDate: Date;
}
