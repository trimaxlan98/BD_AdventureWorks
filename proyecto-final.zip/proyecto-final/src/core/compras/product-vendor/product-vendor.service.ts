import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ProductService } from 'src/core/produccion/product/product.service';
import { Repository } from 'typeorm';
import ProductVendor from './product-vendor.entity';

@Injectable()
export class ProductVendorService {
  constructor(
    @InjectRepository(ProductVendor, 'compras')
    private productVendorRepository: Repository<ProductVendor>,
    private productService: ProductService,
  ) {}

  //   --6.- Listar el comprado que en promedio tardan entre nu días o menos en llegar desde que se realizó el pedido de compra
  async productsByDays(days: number) {
    const product = await this.productService.getProductById(4);
    if (!product) throw new Error('El producto no existe');
    return await this.productVendorRepository
      .createQueryBuilder('ProductVendor')
      .where('ProductVendor.AverageLeadTime < :days', {
        days,
      })
      .andWhere('ProductVendor.ProductID = :id', { id: product.ProductID })
      .getRawMany(); // userId is not a foreign key since its cross-database request
  }

  // --7.- Listar las compras de productos que se esperen lleguen antes del 24 de febrero del 2014;
  async productsBeforeChristmas() {
    const product = await this.productService.getProducts();
    const ids = product.map(({ ProductID }) => ProductID);
    if (!product) throw new Error('El producto no existe');
    return await this.productVendorRepository
      .createQueryBuilder('ProductVendor')
      .where('ProductVendor.DueDate < :date', {
        date: '2014-02-24',
      })
      .andWhere('ProductVendor.ProductID IN (:...ids)', {
        ids,
      })
      .getRawMany();
  }

  // --9.- .- Listar los productos que compra la empresa de Adventure Works y le cuestan más de 40 dólares

  async moreThan(dolars: number) {
    const product = await this.productService.getProducts();
    const ids = product.map(({ ProductID }) => ProductID);
    if (!product) throw new Error('El producto no existe');
    return await this.productVendorRepository
      .createQueryBuilder('ProductVendor')
      .where('ProductVendor.LastReceiptCost > :dolars', {
        dolars,
      })
      .andWhere('ProductVendor.ProductID IN (:...ids)', {
        ids,
      })
      .getRawMany();
  }
  // select t1.ProductID,t1.Name,t1.ProductNumber,t1.ListPrice,t2.LastReceiptCost
  // from Purchasing.ProductVendor t2 join LS_PRODUCCION.Produccion.Production.Product t1
  // on t1.ProductID=t2.ProductID
  // where LastReceiptCost>40
}
