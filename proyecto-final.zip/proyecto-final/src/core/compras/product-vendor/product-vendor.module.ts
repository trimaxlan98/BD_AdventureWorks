import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProductModule } from 'src/core/produccion/product/product.module';
import { ProductVendorController } from './product-vendor.controller';
import ProductVendor from './product-vendor.entity';
import { ProductVendorService } from './product-vendor.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([ProductVendor], 'compras'),
    ProductModule,
  ],
  controllers: [ProductVendorController],
  providers: [ProductVendorService],
})
export class ProductVendorModule {}
