import { Controller } from '@nestjs/common';

@Controller('scrap-reason')
export class ScrapReasonController {}
