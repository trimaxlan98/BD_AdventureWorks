export enum ColorProduct {
  null,
  'Black',
  'Blue',
  'Grey',
  'Multi',
  'Red',
  'Silver',
  'Silver/Black',
  'White',
  'Yellow',
}
