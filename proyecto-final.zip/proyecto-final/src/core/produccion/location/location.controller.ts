import { Controller } from '@nestjs/common';

@Controller('location')
export class LocationController {}
