export interface CreateFields {
  productID: number;
  scrapReasonID: number;
  OrderQty: number;
  ScrappedQty: number;
  StartDate: Date;
  EndData: Date;
  DueDate: Date;
}
