package main;

import Dao.Oferta;

public class App {

	public static void main(String[] args) {
		Oferta operaciones = new Oferta();
		operaciones.obtenerOferta(1);

	}

}
